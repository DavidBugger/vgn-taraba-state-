<?php
session_start();
include('db.php');
$username=$_POST['username'];
$result = mysqli_query($con,"SELECT * FROM member_profile WHERE username='$username'");
$num_rows = mysqli_num_rows($result);
if ($num_rows) {
 header("location: login.php?remarks=failed");
}else {
 $fullname=$_POST['fullname'];
 $register_no=$_POST['register_no'];
 $username=$_POST['username'];
 $password=$_POST['password'];


 if(mysqli_query($con,"INSERT INTO member_profile (fullname, register_no,username, password)VALUES('$fullname', '$register_no', '$username', '$password')")){
	header("location: welcome.php?remarks=success");
 }else{
	 $e=mysqli_error($con);
	header("location: login.php?remarks=error&value=$e");
 }
}
?>
