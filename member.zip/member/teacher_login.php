<?php include "logincheck.php"; ?>
<!DOCTYPE html>
<html>
<head>

	<meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
	<link rel="stylesheet" type="text/css" href="style.css" />
	<title>Teacher_Login</title>
</head>
<body>

</header>
<div id="center">
<div id="center-set">
<div id="signup">
<div id="signup-st">
<div align="center">
<?php
$remarks = isset($_GET['remarks']) ? $_GET['remarks'] : '';
if ($remarks==null and $remarks=="") {
echo ' <div id="reg-head" class="headrg"></div> ';
}
if ($remarks=='success') {
echo ' <div id="reg-head" class="headrg">Registration Success</div> ';
}
if ($remarks=='failed') {
echo ' <div id="reg-head-fail" class="headrg">Registration Failed!, Username exists</div> ';
}
if ($remarks=='error') {
echo ' <div id="reg-head-fail" class="headrg">Registration Failed! <br> Error: '.$_GET['value'].' </div> ';
}
?>
</div>

<div id="login">
<div id="login-st">
  <div class="wrapper">

<form action="" method="POST" id="signin" id="reg" >
  <div class="logo" align="center">
  <img src="assets/img/logo.png" width="50" height="50" alt="logo">
  </div>
  <h2 align="center" style="color:green">Bauchi Teacher's Login </h2>
<?php
$remarks = isset($_GET['remark_login']) ? $_GET['remark_login'] : '';
if ($remarks==null and $remarks=="") {
echo ' <div id="reg-head" class="headrg"></div> ';
}
if ($remarks=='failed') {
echo ' <div id="reg-head-fail" class="headrg"><strong>Login Failed!, Invalid Credentials</strong></div> ';
}
?>

<div class="form-group">
    <label>Username</label>
    <input type="text" name="username" class="form-control" required> <br> <br >

</div>

<div class="form-group">
    <label>Password</label>
    <input type="password" name="password" class="form-control" required> <br> <br >
</div>
<div id="st"><input name="submit" type="submit" value="Login" id="st-btn"/></div>
</form>

</div>
</div>
</div>
</div>
</div>



</body>
</html>
