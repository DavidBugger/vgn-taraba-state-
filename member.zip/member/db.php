<?php
$mysql_hostname = "localhost";
$mysql_user = "vgntarab_vgn_demo";
$mysql_password = "qA36w6AKp7{2";
$mysql_database = "vgntarab_vgn_demo";
$con = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password, $mysql_database);
?>
