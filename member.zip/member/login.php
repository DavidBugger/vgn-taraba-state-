<?php include "logincheck.php"; ?>
<!DOCTYPE html>
<html>
<head>
  <style>
      body{ font: 14px sans-serif;
        /* background-image: url("assets/img/bg3.jpg"); */
       }

      .wrapper{
      width: 50%;
      padding: 20px;
      margin-left:30%;
      margin-top:20px;
      justify-content:center;
      }

      h2{
          color:white;
          font-weight:bold;
          text-align:center;
          font-family: ComingSoon;

      }

input[type=text], select {
width: 100%;
padding: 12px 20px;
margin: 8px 0;
display: inline-block;
border: 1px solid #ccc;
border-radius: 4px;
box-sizing: border-box;
}

input[type=email], select {
width: 100%;
padding: 12px 20px;
margin: 8px 0;
display: inline-block;
border: 1px solid #ccc;
border-radius: 4px;
box-sizing: border-box;
}

input[type=password] {
width: 100%;
padding: 12px 20px;
margin: 8px 0;
display: inline-block;
border: 1px solid #ccc;
border-radius: 4px;
box-sizing: border-box;
}

input[type=submit] {
width: 100%;
background-color: maroon;
color: white;
padding: 14px 20px;
margin: 8px 0;
border: none;
border-radius: 4px;
cursor: pointer;
}

input[type=reset] {
width: 80%;
background-color: maroon;
color: white;
padding: 14px 20px;
margin: 8px 0;
border: none;
border-radius: 4px;
cursor: pointer;
}

input[type=submit]:hover {
background-color: #45a049;
}

form{
  background-color:white;
  border:none;
  padding:15px;
  margin:5px;
  width:100%;
  box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
}

  </style>
	<meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
	<!-- <link rel="stylesheet" type="text/css" href="style.css" /> -->
  <!-- boostrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

	<title>Member Login</title>
</head>
<body>

</header>
<div id="center">
<div id="center-set">
<div id="signup">
<div id="signup-st">
<div align="center">
<?php
$remarks = isset($_GET['remarks']) ? $_GET['remarks'] : '';
if ($remarks==null and $remarks=="") {
echo ' <div id="reg-head" class="headrg"></div> ';
}
if ($remarks=='success') {
echo ' <div id="reg-head" class="headrg">Registration Success</div> ';
}
if ($remarks=='failed') {
echo ' <div id="reg-head-fail" class="headrg">Registration Failed!, Username exists</div> ';
}
if ($remarks=='error') {
echo ' <div id="reg-head-fail" class="headrg">Registration Failed! <br> Error: '.$_GET['value'].' </div> ';
}
?>
</div>

<div id="login">
<div id="login-st">
  <div class="wrapper">

<form action="" method="POST" id="signin" id="reg" >
  <div class="logo" align="center">
  <img src="https://vgntarabastate.org.ng/assets/img/vgn1.jpg" width="50" height="50" alt="logo">
  </div>
  <h2 align="center" style="color:green">VGN Member Login </h2>
<?php
$remarks = isset($_GET['remark_login']) ? $_GET['remark_login'] : '';
if ($remarks==null and $remarks=="") {
echo ' <div id="reg-head" class="headrg"></div> ';
}
if ($remarks=='failed') {
echo ' <div id="reg-head-fail" class="headrg"><strong>Login Failed!, Invalid Credentials</strong></div> ';
}
?>

<div class="form-group">
    <label>Username <span style = "color:red">*</span></label>
    <input type="text" name="username" class="form-control" required> <br> <br >

</div>

<div class="form-group">
    <label>Password<span style = "color:red"> *</span></label>
    <input type="password" name="password" class="form-control" required> <br> <br >
</div>
<div id="st"><input name="submit" type="submit" value="Login" id="st-btn"/></div>
</form>

</div>
</div>
</div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
