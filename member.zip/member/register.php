<?php include "logincheck.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register member</title>
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif;
          /* background-image: url("assets/img/bg3.jpg"); */
         }

        .wrapper{
        width: 50%;
        padding: 20px;
        margin-left:30%;
        margin-top:20px;
        justify-content:center;
        }

        h2{
            color:white;
            font-weight:bold;
            text-align:center;
            font-family: ComingSoon;

        }

input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=email], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: maroon;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=reset] {
  width: 100%;
  background-color: maroon;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: green;
}

form{
    background-color:white;
    border:none;
    padding:15px;
    margin:5px;
    width:100%;
    box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
}

    </style>
</head>
<body>
    <div class="wrapper">
        <!-- <h2 style="color:green">MOE Sign Up</h2> -->

        <div align="center">
        <?php
        $remarks = isset($_GET['remarks']) ? $_GET['remarks'] : '';
        if ($remarks==null and $remarks=="") {
        echo ' <div id="reg-head" class="headrg"></div> ';
        }
        if ($remarks=='success') {
        echo ' <div id="reg-head" class="headrg">Registration Success</div> ';
        }
        if ($remarks=='failed') {
        echo ' <div id="reg-head-fail" class="headrg">Registration Failed!, Username exists</div> ';
        }
        if ($remarks=='error') {
        echo ' <div id="reg-head-fail" class="headrg">Registration Failed! <br> Error: '.$_GET['value'].' </div> ';
        }
        ?>
        </div>

        <form action="execute2.php" onsubmit="return validateForm()" method="post" id="reg">
          <div class="logo" align="center">
          <img src="https://vgntarabastate.org.ng/assets/img/vgn1.jpg" width="50" height="50" alt="logo">
          </div>
          <h2 align="center" style="color:green">VGN Member  Sign Up </h2>
            <div class="form-group">
                <label>Fullname <span style="color:red">*</span></label>
                <input type="text" name="fullname" class="form-control" required> <br> <br >

            </div>

            <div class="form-group">
                <label>Register No <span style="color:red">*</span></label>
                <input type="text" name="register_no" class="form-control" > <br> <br >

            </div>
            
            <div class="form-group">
                <label>Username  <span style="color:red">*</span> </label>
                <input type="text" name="password" class="form-control" required>

            </div>

            <div class="form-group">
                <label>Password <span style="color:red">*</span> </label>
                <input type="password" name="username" class="form-control" required> <br> <br >

            </div>

            

            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Register">
                <input type="reset" class="btn btn-secondary ml-2" value="Reset">
            </div>
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
        </form>
    </div>
</body>
</html>
