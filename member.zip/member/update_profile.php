<?php
	// include "logincheck.php";
	require_once 'session.php';
	include("db.php");

?>


<?php
	if(isset($_POST['update'])){
		$fullname = $_POST['fullname'];
		$register_no = $_POST['register_no'];
		$password = $_POST['password'];
		
		
		
		//exit("hi<hr>");

		if (isset($_FILES['image']['tmp_name'])) {

			//exit("hi $user_check<hr>");
			
			$file=$_FILES['image']['tmp_name'];
			$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
			$image_name= addslashes($_FILES['image']['name']);
			
			$image_type_arr = explode(".", $image_name);
			$image_type = $image_type_arr[sizeof($image_type_arr) - 1];
			$location="img/" . $user_check . '.' .$image_type;
			move_uploaded_file($_FILES["image"]["tmp_name"],$location);
			
			
			//$caption=$_POST['caption'];
			
			//$save=mysqli_query($conn,"INSERT INTO users (image) VALUES ('$location')");
			//header("location: index.php");
			//exit();					
			}
			if($fullname!=NULL &&  $register_no!=NULL && $password!=NULL){
			
$sql = "UPDATE member_profile SET `fullname`='$fullname',`register_no`='$register_no',`password`='$password', `image` ='$location'  WHERE id = '$loggedin_id'";
			
			$result = mysqli_query($con,$sql);
			if($result){
				echo "<div class='alert alert-success'>";
		        echo "<strong>Successfully Updated. You are now redirect to your profile. Wait 2 Secs....</strong>";
		        echo "</div>";
				header("Refresh: 1;URL = welcome.php");
			}else{
				echo "Error!";
			}
			}
		}
?>
<!DOCTYPE html>
<html>
<head>
<style>
	form{
		margin-left: 40%;
	}
	.card-body{
		border-radius: 2px solid red;
	}
</style>


  <!-- bootstrap -->
  <!-- boostrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  <link href="bootstrap-5.0.2-dist/css/bootstrap-grid.min.css" rel="stylesheet">
  <link href="bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- <link href="style.css" rel="stylesheet"> -->
	<meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
	<!-- <link rel="stylesheet" type="text/css" href="style.css" /> -->
	<title>Member Dashboard</title>
</head>
<body>
  <!-- navbar -->

  <nav class="navbar navbar-expand-lg  " style="background-color:maroon;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#" style=" color:white">VGN-Taraba</a>
    <button class="navbar-toggler bg-success" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="color:white" >
      <!-- <span class="navbar-toggler-icon" style="color:white">Menu</span> -->
      Menu
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="welcome.php" style=" color:white">Home</a>
        </li>

         <!-- <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="update_profile.php" style=" color:white">Update Profile</a>
        </li> -->



        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style=" color:white">
            Profile
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="update_profile.php">Update Profile</a></li>
            <li><a class="dropdown-item" href="logout.php">Logout</a></li>

            <!-- <li><a class="dropdown-item" href="#">View Details</a></li> -->

          </ul>
        </li>
        <li class="nav-item" >
          <a class="nav-link active" aria-current="page" href="logout.php" style=" color:white">Logout</a>
        </li>

      </ul>

    </div>
  </div>
</nav>
<!-- end of navbar -->


    <div class="container-fluid">
   <div class="row" id="wrapper">
 
      <div class="col-md-10 col-md-offset-1">
	  <br><br>
	  <h2 style="font-family:Arial; color:maroon;">Update  Profile</h2>
         <div class="panel panel-primary">
		 <!-- <a href = "logout.php" class="btn btn-warning" style="float:right;">Sign Out</a> -->
            <div class="panel-body">
				<center><p>Welcome - <?php echo "<b style='font-family:Arial;color:green; font-size:30px;'>".$loggedin_session."</b>"; ?></p></center><br><br>

				
				<form class="form-horizontal" role="form" action="update_profile.php" method="post" enctype="multipart/form-data">

				<?php
					$sql1="SELECT * FROM member_profile WHERE username = '$loggedin_session'";
					$result1=mysqli_query($con,$sql1);
					while ($row=mysqli_fetch_array($result1)) {
							
				?>

				<div class="form-group">
					 
					<label for="name" class="col-sm-2 control-label">
						FullName
					</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="name" name="fullname" value="<?=$row['fullname']; ?>" />
					</div>
				</div>
				
				<div class="form-group">
					 
					<label for="fathers_name" class="col-sm-2 control-label">
					Register No
					</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="fathers_name" name="register_no" value="<?=$row['register_no']; ?>" />
					</div>
				</div>

				
				<div class="form-group">
					 
					<label for="mothers_name" class="col-sm-2 control-label">
						Password
					</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="mothers_name" name="password" value="<?=$row['password']; ?>" />
					</div>
				</div>
				
				
				
				
			
	
				<div class="form-group">
					 
					<label for="image" class="col-sm-2 control-label">
						Upload Image
					</label>
					<div class="col-sm-10">
						<input type="file" class="form-control" id="image" name="image" />
					</div>
				</div> <br >

				<?php } ?>

				<center><input type="submit" name="update" value="Update" class="btn btn-success"></center>
			</form>

            </div> 
         </div>
         </div>
      </div>
   </div>
      </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</body>
</html>
