<?php include "logincheck.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register_Teacher</title>
    <!-- boostrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  <title></title>
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif;
          /* background-image: url("assets/img/bg3.jpg"); */
         }

        .wrapper{
        width: 50%;
        padding: 20px;
        margin-left:30%;
        margin-top:20px;
        justify-content:center;
        }

        h2{
            color:white;
            font-weight:bold;
            text-align:center;
            font-family: ComingSoon;

        }

input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=email], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=reset] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

form{
    background-color:white;
    border:none;
    padding:15px;
    margin:5px;
    width:100%;
    box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
}

    </style>
</head>
<body>
    <div class="wrapper">
        <!-- <h2 style="color:green">MOE Sign Up</h2> -->

        <div align="center">
        <?php
        $remarks = isset($_GET['remarks']) ? $_GET['remarks'] : '';
        if ($remarks==null and $remarks=="") {
        echo ' <div id="reg-head" class="headrg">Register Here</div> ';
        }
        if ($remarks=='success') {
        echo ' <div id="reg-head" class="headrg">Registration Success</div> ';
        }
        if ($remarks=='failed') {
        echo ' <div id="reg-head-fail" class="headrg">Registration Failed!, Username exists</div> ';
        }
        if ($remarks=='error') {
        echo ' <div id="reg-head-fail" class="headrg">Registration Failed! <br> Error: '.$_GET['value'].' </div> ';
        }
        ?>
        </div>

        <form action="execute2.php" onsubmit="return validateForm()" method="post" id="reg">
          <div class="logo" align="center">
          <img src="assets/img/logo.png" width="50" height="50" alt="logo">
          </div>
          <h2 align="center" style="color:green">Bauchi Teacher's Sign Up </h2>
            <div class="form-group">
                <label>Fullname</label>
                <input type="text" name="fullname" class="form-control" required> <br> <br >

            </div>

            <div class="form-group">
                <label>School Name</label>
                <input type="text" name="school_name" class="form-control" required> <br> <br >

            </div>

            <div class="form-group">
                <label>Email Address (Username)</label>
                <input type="text" name="username" class="form-control" required> <br> <br >

            </div>

            <div class="form-group">
                <label>PSN No (Password)</label>
                <input type="password" name="password" class="form-control" required>

            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-secondary ml-2" value="Reset">
            </div>
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
